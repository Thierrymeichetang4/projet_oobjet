-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3308
-- Généré le :  mar. 21 mai 2024 à 05:49
-- Version du serveur :  5.7.26
-- Version de PHP :  7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `trouvetout`
--

-- --------------------------------------------------------

--
-- Structure de la table `objet`
--

DROP TABLE IF EXISTS `objet`;
CREATE TABLE IF NOT EXISTS `objet` (
  `idobjet` int(11) NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `idofficier` int(11) DEFAULT NULL,
  `idrepert` int(11) NOT NULL,
  `type` varchar(254) DEFAULT NULL,
  `image` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`idobjet`),
  KEY `fk_cherche` (`iduser`),
  KEY `fk_seretrouve` (`idrepert`),
  KEY `fk_trouve` (`idofficier`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `iduser` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(254) DEFAULT NULL,
  `prenom` varchar(254) DEFAULT NULL,
  `email` varchar(254) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `uniqu_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`iduser`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`iduser`, `nom`, `prenom`, `email`, `password`, `uniqu_id`) VALUES
(12, 'meichetang', 'thierry', 'thierrymeichetang4@gmail.com', 'Thierry2002@', 1414295657),
(13, 'fodjo', 'negus', 'negus1@gmail.com', 'Negus2000@', 1689174320),
(14, 'tamdjo', 'brioslin', 'brioslin@gmail.com', 'Brioslin237@', 943719611),
(15, 'tsakeng', 'junior', 'tenevock1@gmail.com', 'Junior2002@', 1040047074);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
