<?php 

    session_start();
    
    $error = "";
    $tou = "";
    
    // Vérification des données envoyées en POST
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Assurez-vous d'avoir inclus correctement votre fichier de connexion à la base de données
        include_once "config[1].php"; 
    
        // Échapper les entrées pour éviter les attaques par injection SQL
        $nom = mysqli_real_escape_string($con, $_POST['nom']);
        $prenom = mysqli_real_escape_string($con, $_POST['prenom']);
        $email = mysqli_real_escape_string($con, $_POST['email']);
        $password = mysqli_real_escape_string($con, $_POST['password']);
        $confirm = mysqli_real_escape_string($con, $_POST['confirm']);
    
        // Vérifier si les champs requis sont vides
        if (empty($nom) || empty($prenom) || empty($email) || empty($password)) {
            $error = "Veuillez remplir tous les champs!";
        } else {
            // Vérifier si les mots de passe correspondent
            if ($password !== $confirm) {
                $error = "Les mots de passe ne correspondent pas!";
            } else {
                // Vérifier la complexité du mot de passe
                if (strlen($password) < 8 || !preg_match('/^(?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?=.*[^\w\d\s:])([^\s]){8,}$/', $password)) {
                    $error = "Le mot de passe doit contenir au moins 8 caractères avec au moins une majuscule, un chiffre, une minuscule et un caractère spécial!";
                } else {
                    // Vérifier si l'email est valide
                    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                        $error = "$email n'est pas une adresse e-mail valide!";
                    } else {
                        // Vérifier si l'email est déjà utilisé
                        $sql = mysqli_query($con, "SELECT * FROM utilisateur WHERE email = '$email'");
                        if (mysqli_num_rows($sql) > 0) {
                            $error = "$email est déjà utilisé, veuillez utiliser une autre adresse e-mail!";
                        } else {
        
                            $ran_id = rand(time(), 100000000);
                            $status = "en ligne";
                            $encrypt_pass = hash('sha256', $password);
                            $insert_query = mysqli_query($con, "INSERT INTO utilisateur (nom, prenom, email, password, status, ran_id) VALUES ('$nom','$prenom','$email','$encrypt_pass','$status','$ran_id')");
                            if ($insert_query) {
                                // Redirection après inscription réussie
                                $_SESSION['uniqu_id'] = mysqli_insert_id($con);
                                header("location: pages-connexion.php");
                                exit(); // Terminer le script après la redirection
                            } else {
                                $error = "Une erreur s'est produite lors de l'inscription, veuillez réessayer!";
                            }
                        }
                    }
                }
            }
        }
    }
    ?>
    