<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet"  href="bootstrap/Bootstrap.min.css">
	<link rel="stylesheet"  href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="js/Bootstrap.js">
	<!--<link rel="stylesheet"  href="style.css">
	<link rel="stylesheet"  href="stylep.css">-->
	<title></title>
</head>
<body  style="text-align: center;">
	<header style="background-color: #f4f4f4; padding: 10px;text-align: center;font-size: 20px;">
        <div class="logo">
            <img src="image1.jpg" style="width: 55px;height: 55px;">
            <h1> J'ai retrouvé un objet  </h1>
        </div>
    </header>
		
			<form action="trouver_t.php" method="POST"><br><br><br>
			
			
				<label class="label col-md-2 control-label">Type de document</label>
			
					<select name="typeD">
						<option value="acte de naissance" >Acte de naissance</option>
						<option value="cni" >Carte nationale d'identite</option>
						<option value="passeport" >Passeport</option>
					</Select><br><br>
				
				<label class="label col-md-2 control-label">Nom_Objet</label>
				
					<input type="text" class="form-control" name="name" required placeholder="Entrez le nom qui est renseigner sur la carte"><br><br>
				
				<label class="label col-md-2 control-label">prenom_Objet</label>
				
					<input type="text" class="form-control" name="surname" required placeholder="Entrez le prenom qui est renseigner sur l' objet "><br><br>
					<label class="label col-md-2 control-label">Numero ID </label>
				
					<input type="text" class="form-control" name="id" required placeholder="Entrez le Numero identifiant l'objet trouvé "><br><br>
			
				<label class="label col-md-2 control-label">Date_de_Naissance</label>
				
					<input type="date" class="form-control" name="date" required placeholder="Entrez la date de naissance mentionnée sur l' objet "><br><br>
			
				<label class="label col-md-2 control-label">Nom_du_trouveur</label>
				
					<input type="text" class="form-control" name="Nom_du_trouveur" required placeholder="Entrez son adresse"><br><br>

				<label class="label col-md-2 control-label">son telephone</label>
				
					<input type="number" class="form-control" name="number" required placeholder="Entrez son telephone"><br><br>
			
          		<label>Selectionnez l'image de la piece</label>
          		<input type="file" name="image" accept="image/x-png,image/gif,image/jpeg,image/jpg" required><br><br>
        	<input type="submit" name="valider"  value="S'inscrire !">
			
			</form>
		</div>
	</div><br><br>

	 <footer>
        <div style="margin-bottom: 50px;background-color: #f4f4f4;color: #333;padding: 1em;text-align: center;max-width: 12000px;margin: 100 auto;padding: 1em; background-color: #f4f4f4; padding: 10px;text-align: center;font-size: 20px;">
            <p>&copy; 2024 [GROUPE 4] - Tous les droits reservés</p>   
        </div>
    </footer>
</body>
</html>