
	<!DOCTYPE html>
	<html>
	<head>
		<meta charset="utf-8">
		<title></title>
	</head>
	<body>
		<?php 
	try {
		$bd= new PDO ('mysql:host=localhost;dbname=trouvetout','root','');
	} catch (Exception $e) {
		die('Erreur'.$e->getMessage());
	}
	if (isset($_POST['valider'])) {
		$req=$bd->prepare('SELECT idobjet FROM objet WHERE nompropietaire= :nom ');
		$req->execute(array('nom'=> $_POST['name']));
		$resultat=$req->fetch();
		if (!$resultat) {
			$nom=$_POST['name'];
		$prenom=$_POST['surname'];
		$date=$_POST['date'];
		$id=$_POST['id'];
		$numero=$_POST['number'];
		$type=$_POST['typeD'];	
		$img=$_POST['image'];

		$tmpName=$_FILES['file'] ['tmp_name'];
		$name=$_FILES['file']['name'];
		$size=$_FILES['file']['size'];
		move_uploaded_file($tmpName,'./images/'.$name);
		
		$req=$bd->prepare('INSERT INTO objet (typedocument,nompropietaire,prenompropietaire,datenaisspropietaire,adressepropietaire,telephonepropietaire,image) VALUES (:typeD, :nom, :prenom, :daten, :adresse, :numero, :img)');
		$req->execute(array('typeD'=>$type,
							'nom'=>$nom,
							'prenom'=>$prenom,
							'daten'=>$date,
							'adresse'=>$address,
							'numero'=>$numero,
							'img'=>$img));
		?> <strong>PIECE ENREGISTRE </strong><?php 
		
		}else{
			$rep=$bd->prepare('SELECT * FROM objet WHERE nompropietaire= :nom ORDER BY idobjet ');
			$req->execute(array('nom'=> $_POST['name']));
			while ($donnees=$rep->fetch()) {
				?>
				<p>
					<?php echo htmlspecialchars($donnees['nompropietaire']); ?>  <?php echo htmlspecialchars($donnees['prenompropietaire']) ; ?>  <?php echo htmlspecialchars($donnees['datenaisspropietaire']) ; ?> <?php echo htmlspecialchars($donnees['adressepropietaire']) ; ?> <?php echo htmlspecialchars($donnees['telephonepropietaire']) ; ?>
				</p>
				<?php
			}
		}
	}
		
			
	?>
	
	</body>
	</html>
		