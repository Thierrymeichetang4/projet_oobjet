<?php 
$con = mysqli_connect("localhost", "root", "", "trouvetout","3308");
$req = mysqli_query($con, "SET NAMES UTF8");
?>