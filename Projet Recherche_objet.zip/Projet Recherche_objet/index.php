<!DOCTYPE html>
    <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta name="author" content="NoS1gnal"/>

            <link href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css" rel="stylesheet" />
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
            <title>Connexion</title>
        </head>
        <body>
            <header style="background-color: #f4f4f4; padding: 10px;text-align: center;font-size: 20px;">
        <div class="logo">
            <img src="image1.jpg" style="width: 55px;height: 55px;">
           <marquee direction = "rigth"> <h1>BIENVENUE SUR SEARCH ID's </h1></marquee>
        </div>
    </header>  
        <div class="login-form">
 
        <?php 
session_start(); // Démarrage de la session
require_once 'config[1].php'; // On inclut la connexion à la base de données
if (isset($_POST['login'])) {

    $email = mysqli_real_escape_string($con, $_POST['email']);

    $password = mysqli_real_escape_string($con, $_POST['password']);

    if (!empty($email) && !empty($password)) {
        $sql = mysqli_query($con, "SELECT * FROM utilisateur WHERE email = '$email'");
        if (mysqli_num_rows($sql) > 0) {
            $row = mysqli_fetch_assoc($sql);
            $user_pass = hash('sha256', $password);
            $passwords = $row['password'];
            if ($password === $passwords) {
                    $_SESSION['uniqu_id'] = $row['uniqu_id'];
                    header("location:controlle/control.html");
                } else {
                    $error = "Something went wrong. Please try again!";
                }
            } else {
                $error =  "Email ou mot de passe  Incorrect!";
            }
        } else {
            $error = "$email -  n 'est pas dans notre base de donnees!";
        }
    } else {
        $error = "";
    }

?>


            <form action="" method="post">
                <h2 class="text-center">SEARCH ID's</h2>     
                <p><?php echo $error; ?></p>  
                <div class="form-group">
                    <input type="email" name="email" class="form-control" placeholder="email" required="required" autocomplete="off">
                </div>
                <div class="form-group">
                    <input type="password" name="password" class="form-control" placeholder="mots de passe" required="required" autocomplete="off">
                </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-primary btn-block" name="login" value="connexion"><br>
                    <p><a href="inscription[1].php">Inscription</a></p>
                </div>   
            </form>
        </div>
        <style>
            .login-form {
                width: 340px;
                margin: 50px auto;
            }
            .login-form form {
                margin-bottom: 15px;
                background: #f7f7f7;
                box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
                padding: 30px;
            }
            .login-form h2 {
                margin: 0 0 15px;
            }
            .form-control, .btn {
                min-height: 38px;
                border-radius: 2px;
            }
            .btn {        
                font-size: 15px;
                font-weight: bold;
            }
        </style>
        <br><br>

         <footer>
        <div style="margin-bottom: 50px;background-color: #f4f4f4;color: #333;padding: 1em;text-align: center;max-width: 12000px;margin: 100 auto;padding: 1em; background-color: #f4f4f4; padding: 10px;text-align: center;font-size: 20px;">
            <p>&copy; 2024 [GROUPE 4] - Tous les droits reservés</p>  
        </div>
    </footer>
        </body>
</html>




      