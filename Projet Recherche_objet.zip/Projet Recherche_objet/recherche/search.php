<?php
// Connexion à la base de données
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "trouvetout2";
$port=3308;

$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Erreur de connexion à la base de données : " . $conn->connect_error);
}

// Récupérer la requête de recherche
$query = $_GET['query'];

// Préparer et exécuter la requête SQL
$stmt = $conn->prepare("SELECT * FROM objetperdu WHERE idobjet LIKE ?");
$searchQuery = "%" . $query . "%";
$stmt->bind_param("s", $searchQuery);
$stmt->execute();
$result = $stmt->get_result();

// Afficher les résultats de la recherche
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<div class='result'>";
        echo "<h3>" . $row["idobjet"] . "</h3>";
        echo "<p>" . $row["iduser "] . "</p>";
        echo "</div>";
    }
} else {
    echo "<p>Aucun résultat trouvé.</p>";
}

$stmt->close();
$conn->close();
?>