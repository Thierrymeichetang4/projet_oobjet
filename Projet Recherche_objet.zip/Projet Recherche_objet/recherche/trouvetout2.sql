/*==============================================================*/
/* Nom de SGBD :  MySQL 5.0                                     */
/* Date de création :  24/04/2024 19:21:01                      */
/*==============================================================*/


/*==============================================================*/
/* Table : objet                                                */
/*==============================================================*/
create table objet
(
   idobjet              int not null,
   nompropietaire       varchar(254),
   prenompropietaire    varchar(254),
   datenaisspropietaire datetime,
   adressepropietaire   varchar(254),
   telephonepropietaire int,
   primary key (idobjet)
);

/*==============================================================*/
/* Table : objetperdu                                           */
/*==============================================================*/
create table objetperdu
(
   idobjet              int not null,
   iduser               int,
   primary key (idobjet)
);

/*==============================================================*/
/* Table : objettrouve                                          */
/*==============================================================*/
create table objettrouve
(
   idobjet              int not null,
   iduser               int,
   idrepert             int not null,
   primary key (idobjet)
);

/*==============================================================*/
/* Table : pointrepert                                          */
/*==============================================================*/
create table pointrepert
(
   idrepert             int not null,
   nomrepert            varchar(254),
   adreeserepert        varchar(254),
   telephonerepert      int,
   primary key (idrepert)
);

/*==============================================================*/
/* Table : utilisateur                                          */
/*==============================================================*/
create table utilisateur
(
   iduser               int not null,
   nom                  varchar(254),
   prenom               varchar(254),
   telephone            int,
   adresse              varchar(254),
   primary key (iduser)
);

alter table objetperdu add constraint fk_generalisation_3 foreign key (idobjet)
      references objet (idobjet) on delete cascade on update cascade;

alter table objetperdu add constraint fk_cherche foreign key (iduser)
      references utilisateur (iduser) on delete cascade on update cascade;

alter table objettrouve add constraint fk_generalisation_2 foreign key (idobjet)
      references objet (idobjet) on delete cascade on update cascade;

alter table objettrouve add constraint fk_renseigne foreign key (iduser)
      references utilisateur (iduser) on delete cascade on update cascade;

alter table objettrouve add constraint fk_setrouve foreign key (idrepert)
      references pointrepert (idrepert) on delete cascade on update cascade;

